from django.contrib import admin
from .models import Mascotas, Tratamientos

admin.site.register(Mascotas)
admin.site.register(Tratamientos)
